#!/bin/bash
# ------------------------------------------------------------------
# Project: Simple Library Management System
# Author: Group 10 (Ragyam, Ravi, Rishikesh, Vishal)
# Course: Operating System Lab (PCC-CS592)
# ------------------------------------------------------------------

# --- Global Variables for Data Files ---
BOOK_FILE="books.csv"
MEMBER_FILE="members.csv"
ISSUE_FILE="issue.csv"

# --- Initialization Module ---
init_db() {
    if [ ! -f "$BOOK_FILE" ]; then
        echo "ID,Title,Author,Category,Total,Available" > "$BOOK_FILE"
    fi
    if [ ! -f "$MEMBER_FILE" ]; then
        echo "ID,Name,Dept,Contact" > "$MEMBER_FILE"
    fi
    if [ ! -f "$ISSUE_FILE" ]; then
        echo "BookID,MemberID,IssueDate,DueDate,ReturnDate" > "$ISSUE_FILE"
    fi
}

# --- Module: Add New Book ---
add_book() {
    echo "---------------------------------"
    echo "       ADD NEW BOOK"
    echo "---------------------------------"
    read -p "Enter Book ID (Integer): " bid
    
    if grep -q "^$bid," "$BOOK_FILE"; then
        echo "Error: Book ID $bid already exists."
        return
    fi
    
    read -p "Enter Title: " title
    read -p "Enter Author: " author
    read -p "Enter Category: " category
    read -p "Enter Quantity: " qty
    
    clean_title=$(echo "$title" | tr ',' ' ')
    clean_author=$(echo "$author" | tr ',' ' ')
    
    echo "$bid,$clean_title,$clean_author,$category,$qty,$qty" >> "$BOOK_FILE"
    echo "Success: Book added."
}

# --- Module: Add New Member ---
add_member() {
    echo "---------------------------------"
    echo "       ADD NEW MEMBER"
    echo "---------------------------------"
    read -p "Enter Member ID: " mid
    
    if grep -q "^$mid," "$MEMBER_FILE"; then
        echo "Error: Member ID exists."
        return
    fi
    
    read -p "Enter Name: " name
    read -p "Enter Department: " dept
    read -p "Enter Contact: " contact
    
    clean_name=$(echo "$name" | tr ',' ' ')
    
    echo "$mid,$clean_name,$dept,$contact" >> "$MEMBER_FILE"
    echo "Success: Member registered."
}

# --- Module: Issue Book ---
issue_book() {
    echo "---------------------------------"
    echo "         ISSUE BOOK"
    echo "---------------------------------"
    read -p "Enter Member ID: " mid
    
    if ! grep -q "^$mid," "$MEMBER_FILE"; then
        echo "Error: Member not found."
        return
    fi
    
    read -p "Enter Book ID: " bid
    book_record=$(grep "^$bid," "$BOOK_FILE")
    
    if [ -z "$book_record" ]; then
        echo "Error: Book not found."
        return
    fi
    
    available=$(echo "$book_record" | cut -d',' -f6)
    
    if [ "$available" -gt 0 ]; then
        issue_date=$(date +%Y-%m-%d)
        due_date=$(date -d "+14 days" +%Y-%m-%d)
        
        awk -F, -v id="$bid" 'BEGIN{OFS=","} $1==id{$6=$6-1} 1' "$BOOK_FILE" > temp.csv && mv temp.csv "$BOOK_FILE"
        
        echo "$bid,$mid,$issue_date,$due_date,NotReturned" >> "$ISSUE_FILE"
        echo "Success: Book issued. Due: $due_date"
    else
        echo "Error: Book out of stock."
    fi
}

# --- Module: Return Book ---
return_book() {
    echo "---------------------------------"
    echo "         RETURN BOOK"
    echo "---------------------------------"
    read -p "Enter Book ID: " bid
    read -p "Enter Member ID: " mid
    
    trans_line=$(grep "^$bid,$mid,.*,NotReturned$" "$ISSUE_FILE")
    
    if [ -z "$trans_line" ]; then
        echo "Error: No active issue record found."
        return
    fi

    issue_date_str=$(echo "$trans_line" | cut -d',' -f3)
    due_date_str=$(echo "$trans_line" | cut -d',' -f4)
    return_date_str=$(date +%Y-%m-%d)
    
    due_sec=$(date -d "$due_date_str" +%s)
    ret_sec=$(date -d "$return_date_str" +%s)
    
    diff=$((ret_sec - due_sec))
    days_late=$((diff / 86400))
    
    echo "Due Date: $due_date_str"
    echo "Return Date: $return_date_str"
    
    if [ $days_late -gt 0 ]; then
        fine=$((days_late * 5))
        echo "OVERDUE by $days_late days — Fine: Rs. $fine"
        read -p "Fine collected? (y/n): " ans
        if [ "$ans" != "y" ]; then
            echo "Return cancelled."
            return
        fi
    else
        echo "Returned on time."
    fi
    
    awk -F, -v id="$bid" 'BEGIN{OFS=","} $1==id{$6=$6+1} 1' "$BOOK_FILE" > temp2.csv && mv temp2.csv "$BOOK_FILE"
    
    sed -i "s/$bid,$mid,$issue_date_str,$due_date_str,NotReturned/$bid,$mid,$issue_date_str,$due_date_str,$return_date_str/" "$ISSUE_FILE"
    
    echo "Book return processed."
}

# --- Module: View Inventory ---
view_inventory() {
    echo "-----------------------------------------------------------------"
    echo " ID | Title | Author | Avail | Total "
    echo "-----------------------------------------------------------------"
    awk -F, 'NR>1 {printf " %-3s | %-20s | %-15s | %-5s | %-5s\n",$1,$2,$3,$6,$5}' "$BOOK_FILE"
    echo "-----------------------------------------------------------------"
}

# --- Module: Defaulters ---
generate_defaulters() {
    echo "---------------------------------"
    echo "      LIST OF DEFAULTERS"
    echo "---------------------------------"
    current_sec=$(date +%s)
    
    tail -n +2 "$ISSUE_FILE" | while IFS=, read -r bid mid is_date due_date ret_date; do
        if [ "$ret_date" = "NotReturned" ]; then
            due_sec=$(date -d "$due_date" +%s)
            if [ $current_sec -gt $due_sec ]; then
                echo "Member: $mid | Book: $bid | Due: $due_date | OVERDUE"
            fi
        fi
    done
}

# --- Main Program ---
init_db

echo "=== LIBRARY SYSTEM MENU ==="
echo "1. Add Book"
echo "2. Add Member"
echo "3. Issue Book"
echo "4. Return Book"
echo "5. View Inventory"
echo "6. Show Defaulters"
echo "7. Exit"
echo "==========================="

while true; do
    echo ""
    read -p "Select Option: " opt
    
    case $opt in
        1) add_book ;;
        2) add_member ;;
        3) issue_book ;;
        4) return_book ;;
        5) view_inventory ;;
        6) generate_defaulters ;;
        7) echo "Bye!"; exit ;;
        *) echo "Invalid option." ;;
    esac
done